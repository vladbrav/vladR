## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup---------------------------------------------------------------
library(mypak1)

## ------------------------------------------------------------------------
library(survival)
data(rats)
mod1 <- AFTexp(rats$time,rats$status,rats$rx,rats)
mod2 <- AFTweib(rats$time,rats$status,rats$rx,rats)
mod3 <- AFTlog(rats$time,rats$status,rats$rx,rats)

## ------------------------------------------------------------------------
mod1
mod2
mod3

